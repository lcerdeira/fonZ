fonZ
fonZ searches among the installed fonts
and let the user choose
among those found
which one to use
for the website

html css javascript
fonZ for now has 4 files
1 html example page with css embedded for the page and fonZ
2 js one for fonZ application and the other for a list of fonts - only the name
1 image svg optional for the background

Usage
download the files and put the scripts in a folder named js
and the image in his img folder
or use other names or locations and change the links in the example page
or
download and unzip the zip file
open the example page in a browser and run the script

fonZ can run in any location with or without a webserver
without server fonZ loss some functions and the user cannot save his choice
because fonZ need some cookie for stored the name of fonts found
if it find something

Usage without the example page
put the code at bottom of example page in your page
put the css code of fonZ in a css file or embedd it
link the scripts
done

Add other name fonts
add the names to the script for fonts where are stored the existing fonts and in the same format i.e. 'a fonts','another','serif','etc etc',
for now fonZ support until 324 fonts
but is quite simple enlarge that limit
